# Frontend (React)

## Setup
1. `cd frontend`
2. `npm install`
3. `npm start`

This is a minimal React skeleton; replace with your design and components.
