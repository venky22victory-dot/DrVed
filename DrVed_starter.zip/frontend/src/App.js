import React from 'react';

export default function App(){
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:24}}>
      <h1>Dr. Ved - Frontend (Starter)</h1>
      <p>This is a placeholder React app. Replace with your real UI.</p>

      <section>
        <h2>Sample Payment Flow</h2>
        <p>Clicking the button below should call your backend to create an order, then open Razorpay checkout (not implemented here).</p>
        <button onClick={() => alert('Implement call to /api/create-order on backend')}>Pay (placeholder)</button>
      </section>

      <section style={{marginTop:20}}>
        <h2>Placeholders</h2>
        <ul>
          <li>/public/images/placeholder.png — product images</li>
          <li>Admin panel: implement file upload & product management</li>
        </ul>
      </section>
    </div>
  );
}
