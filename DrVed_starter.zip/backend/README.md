# Backend (Express)

## Setup
1. Copy `.env.example` -> `.env` and fill values
2. `npm install`
3. `npm run dev` (requires nodemon)

## Razorpay
- This project includes a sample `create-order` route which uses Razorpay SDK.
- Keep keys in environment variables; never commit `.env`.
