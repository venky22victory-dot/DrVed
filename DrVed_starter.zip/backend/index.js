require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const Razorpay = require('razorpay');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 5000;

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_keyid',
  key_secret: process.env.RAZORPAY_KEY_SECRET || 'rzp_test_secret'
});

// Basic health route
app.get('/api/health', (req, res) => res.json({ status: 'ok', environment: process.env.NODE_ENV || 'development' }));

// Example: create order (Razorpay)
app.post('/api/create-order', async (req, res) => {
  try {
    const { amount, currency = 'INR', receipt = 'receipt#1' } = req.body;
    if (!amount) return res.status(400).json({ error: 'amount is required (in paise)' });
    const options = {
      amount: amount, // amount in paise
      currency,
      receipt,
      payment_capture: 1
    };
    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'failed to create order', details: err.message });
  }
});

// Example: verify payment signature (simple template)
app.post('/api/verify-payment', (req, res) => {
  // Implement verification using crypto if you use webhooks or payments
  res.json({ status: 'verification-endpoint-placeholder' });
});

app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
});
